finish idle-body-linked-image-without-alt-tag-no-textnode

schema.org json ld detect
strucured data summary
